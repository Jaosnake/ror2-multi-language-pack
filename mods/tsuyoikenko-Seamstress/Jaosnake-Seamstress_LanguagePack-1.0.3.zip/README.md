# 🌍 Jaosnake-Seamstress_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Seamstress** by **tsuyoikenko**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| tsuyoikenko-Seamstress | `1.7.4` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 35/35 |
| 🇩🇪 | German | `de` | 35/35 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 35/35 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 35/35 |
| 🇫🇷 | French | `FR` | 35/35 |
| 🇮🇹 | Italian | `IT` | 35/35 |
| 🇯🇵 | Japanese | `ja` | 35/35 |
| 🇰🇷 | Korean | `ko` | 35/35 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 35/35 |
| 🇷🇺 | Russian | `RU` | 35/35 |
| 🇹🇷 | Turkish | `tr` | 35/35 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 35/35 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 35/35 |
| 🟩 | Esperanto | `eo` | 35/35 |
| 🏛️ | Latin | `la` | 35/35 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [tsuyoikenko](https://thunderstore.io/c/riskofrain2/p/tsuyoikenko/Seamstress/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
