# Changelog

## 1.0.0

- Add compatibility for dynamic Moonstorm translation values.
- Tested with the original R2API.Language and P.E.L.E.
