# 🌍 Jaosnake-Ravager_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.4-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)
![PELE](https://img.shields.io/badge/PELE-Required-brightgreen)

Multi-language translation pack for **Ravager** by **public_ParticleSystem**.

> 🌐 🇻🇦 🇺🇦 Latim, Esperanto, and Ukrainian are included in this pack. To enable them as selectable in-game languages, install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/), where they are supported natively.

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| Jaosnake-PELE | `1.0.2` |
| public_ParticleSystem-Ravager | `1.6.0` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Languages
| Flag | Language |
|------|----------|
| 🇨🇳 | Chinese (Simplified) |
| 🇺🇸 | English |
| 🌐 | Esperanto |
| 🇫🇷 | French |
| 🇩🇪 | German |
| 🇮🇹 | Italian |
| 🇯🇵 | Japanese |
| 🇰🇷 | Korean |
| 🇻🇦 | Latin |
| 🇧🇷 | Portuguese (BR) |
| 🇷🇺 | Russian |
| 🇪🇸 | Spanish (LATAM) |
| 🇪🇸 | Spanish (Spain) |
| 🇹🇷 | Turkish |
| 🇺🇦 | Ukrainian |

## Gameplay configuration

Some of the original mod’s options can alter behaviors described by the translations.

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [public_ParticleSystem](https://thunderstore.io/c/riskofrain2/p/public_ParticleSystem/Ravager/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
