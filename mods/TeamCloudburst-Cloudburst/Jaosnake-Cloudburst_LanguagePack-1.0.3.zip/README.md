# 🌍 Jaosnake-Cloudburst_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)
[![PELE](https://img.shields.io/badge/%E2%9A%A1%20P.E.L.E.-Required%20for%20UA%20%2F%20eo%20%2F%20la-orange)](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)

Complete multi-language translation pack for **Cloudburst** by **TeamCloudburst** (`TeamCloudburst-Cloudburst-0.5.0`), adding full localization across **15 languages** (**78 localized strings per language**).

> ⚠️ **IMPORTANT NOTICE / AVISO IMPORTANTE (P.E.L.E. REQUIRED):**
> **Ukrainian (`UA`)**, **Esperanto (`eo`)**, and **Latin (`la`)** translations are fully included in this pack, but **Risk of Rain 2 does not natively support or display these languages in the game menu**.
> 
> To play with any of these 3 languages, you **MUST download and install [P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** (Language Expander & Loader), which unlocks and enables them in-game!
> 
> *Para jogar em Ucraniano, Esperanto ou Latim, é **obrigatório** instalar o mod **[P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)**, pois o Risk of Rain 2 padrão não oferece suporte nativo a esses idiomas no seletor do jogo.*

---

## 📦 Dependencies
| Package | Version | Requirement |
|---------|---------|-------------|
| `TeamCloudburst-Cloudburst-0.5.0` | `0.5.0` | Required |
| `RiskofThunder-R2API_Language` | `1.1.0` | Required |
| **[Jaosnake-PELE](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** | Latest | **Required for Ukrainian (`UA`), Esperanto (`eo`), and Latin (`la`)** |

---

## 🌐 Languages (15)
| Flag | Code | Language | Support & Requirements |
|------|------|----------|------------------------|
| 🇺🇸 | `en` | English | Native Base |
| 🇧🇷 | `pt-BR` | Português (Brasil) | Native |
| 🇪🇸 | `es-ES` | Español (España) | Native |
| 🇲🇽 | `es-419` | Español (Latinoamérica) | Native |
| 🇫🇷 | `FR` | Français | Native |
| 🇮🇹 | `IT` | Italiano | Native |
| 🇩🇪 | `de` | Deutsch | Native |
| 🇷🇺 | `RU` | Русский | Native |
| 🇺🇦 | `UA` | Українська | ⚡ **[Requires P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** |
| 🇹🇷 | `tr` | Türkçe | Native |
| 🇨🇳 | `zh-CN` | 简体中文 | Native |
| 🇯🇵 | `ja` | 日本語 | Native |
| 🇰🇷 | `ko` | 한국어 | Native |
| 🌐 | `eo` | Esperanto (x-system) | ⚡ **[Requires P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** |
| 🏛️ | `la` | Lingua Latina | ⚡ **[Requires P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** |

---

## 🎮 Gameplay & Configuration
Skill and item values describe Cloudburst v0.5.0 default settings. Secondary DLL tokens hardcoded in C# default to English.

## 📦 Installation / Instalação

1. Install **Cloudburst** (`TeamCloudburst-Cloudburst-0.5.0`) via **r2modman** or **Thunderstore Mod Manager**.
2. Install this language pack (`Jaosnake-Cloudburst_LanguagePack-1.0.3`).
3. **If playing in Ukrainian, Esperanto, or Latin:**
   - Download and install **[P.E.L.E.](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/)** (required to enable these languages in-game).
4. Launch Risk of Rain 2 — translations will load automatically according to your selected language!

---

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [TeamCloudburst](https://thunderstore.io/c/riskofrain2/p/TeamCloudburst/Cloudburst/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
