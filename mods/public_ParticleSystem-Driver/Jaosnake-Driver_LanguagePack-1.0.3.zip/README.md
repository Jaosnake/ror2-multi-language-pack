# 🌍 Jaosnake-Driver_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Driver** by **public_ParticleSystem**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| public_ParticleSystem-Driver | `2.4.4` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 302/302 |
| 🇩🇪 | German | `de` | 302/302 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 302/302 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 302/302 |
| 🇫🇷 | French | `FR` | 302/302 |
| 🇮🇹 | Italian | `IT` | 302/302 |
| 🇯🇵 | Japanese | `ja` | 302/302 |
| 🇰🇷 | Korean | `ko` | 302/302 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 302/302 |
| 🇷🇺 | Russian | `RU` | 302/302 |
| 🇹🇷 | Turkish | `tr` | 302/302 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 302/302 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 302/302 |
| 🟩 | Esperanto | `eo` | 302/302 |
| 🏛️ | Latin | `la` | 302/302 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [public_ParticleSystem](https://thunderstore.io/c/riskofrain2/p/public_ParticleSystem/Driver/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
