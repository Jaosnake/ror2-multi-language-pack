```
Changelog order: (as of v1.0.0 and onwards)
(general => specifics, alphabetical)
- Plugin
- Storms
- Difficulty
- Stages
- Interactables
- Artifacts
- Elites
- Enemies
- Allies
- Items
```

## SWAN SONG EXTENDED
### 1.1.3
```
    SwanSongExtended:
- Updated RainrotSUL dependency
```

### 1.1.2
```
    Executive Card:
- Closed shop terminals will now reopen if an Executive Card holder is within 50m

    Loyalty Card:
- Closed shop terminals will now reopen if a Loyalty Card holder is within 20m
- Reduced cash back value: $25 -> $20
* For 2R4R, this places the value of the bonus items at the cost of a Category chest *
```

### 1.1.1
```
    Brittle Crown:
- Fixed an issue where disabling the Brittle Crown rework would cause Brittle Crown pickups to glitch out and multiply infinitely

    Crystal Ball:
- Can no longer target enemies who are invincible, including the Immortal Gup from HexingChaos

    Plated Pereopod:
- Fixed description missing unconditional movement speed text
```

### 1.1.0: Health and Armor Update
```
    Storms:
- Fixed an issue where storm delay modifiers were added to the HUD timer rather than subtracting, causing the HUD to incorrectly display when the Storm would actually start

    Chocolate Coin:
- Fixed display name using the internal config name

    Flower Crown:
- Reworked, now a Common item that adds +12% HP

    Frozen Turtle Shell:
- Reduced unconditional armor: 10+10 -> 0
- Increased unconditional max health: 0% -> 8%+8%

    Greedy Ring:
- Added
- Increase income and regen for a large period on interaction

    Jellyfish Necklace:
- Disabled

    Plated Pereopod:
- Added
- Increase movement speed while shields are down. Corrupts Pauls Goat Hoof

    Snapping Stone:
- No longer creates Sparks when triggered
- Now zaps 2 nearby enemies using the Amplified damage

    Volatile Fuse:
- Disabled
```

### 1.0.19
```
    Gamma Knife:
- Fix incorrect stats
```

### 1.0.18
```
    Howling Elites:
- Fixed Squall beam being invisible to clients in Multiplayer
```

### 1.0.17
```
    Storms:
- Fixed Teleporter Boss sometimes being spawned as a Storm Elite during storms
```

### 1.0.15
```
    Storms:
- Now exposes a storm delay modifier that can be accessed by other mods: StormsCore.GetStormDelayModifierSeconds

    Egg:
- Can no longer drop Eggs from forced on-kill effects
```

### 1.0.14
```
    Storm Elites:
- Will no longer gain a period of invulnerability after breaking a health gate if they are currently weakened (sheltered)    

    Golden Egg:
- Changed pickup description to be more elusive
- Now has a transformation notification that identifies the item it turns into

    Kaleidoskull:
- Can now apply Acolyte's Haunt 
- Proc coefficient no longer reduces the stacks applied
- Reduced debuff trigger chance: 100% -> 50% times proc coefficient

    Photograph:
- Print counts per character are now passively tracked and applied on inventory refresh
- Deployable Minions that inherit Photograph now use their owner's print count
* Essentially, this is a RetroactiveMacro-style buff and an Engineer buff rolled into one *
```

### 1.0.13
```
    Cloud in a Bottle:
- Fixed cooldown not being counted as a cooldown debuff (triggering Raincoat and not Crucible)

    Copper Fork:
- Fixed cooldown not being counted as a cooldown debuff (triggering Raincoat and not Crucible)

    Hypo-Threader:
- Can no longer proc itself???

    Quarantined Contaminant:
- Fixed cooldown not being counted as a cooldown debuff (triggering Raincoat and not Crucible)
```

### 1.0.12
```
    Storms:
- Fixed Teleporter Boss sometimes being spawned as a Storm Elite during storms

    Howling Elites:
- Added configuration for most Howling Elite abilities

    Surging Elites:
- Added configuration for most Surging Elite abilities
- Fixed larger Surging Elites not dropping a cannonball with more Bounce!
- Fixed Surging Elites sometimes dashing post-mortem
- Surge dash now targets players more consistently
```

### 1.0.11
```
    Styorms:
- Removed errant debug spam related to Cyclones and the Squall state

    Amethyst Fragment:
- Can no longer be temporary
* This is to avoid situations where temporary copies can't be used due to your Equipment's cooldown *
- Fixed? guaranteed Equipment Barrel spawning far away from stage entry position
- Fixed guaranteed Equipment Barrel using unscaled cost

    Hypo-Threader:
- Added Crafting recipe: Lens Makers Glasses + Ukulele
```

### 1.0.10
```
    Storms:
- Fixed Teleporter Boss sometimes being spawned as a Storm Elite during storms
- Reduced meteor radius: 10 -> 9

    Howling Elites:
- Fixed incorrect visual effect for "Wind Missile"
- Increased Squall tracking delay: 0.45s -> 0.5s

    Surging Elites:
- Reduced base damage of waves: 8 -> 6

    Stillborn Prayer:
- Now has a transform notification!
- Fixed an issue where using this equipment would put the next equipment on cooldown

    Coin Gun:
- Moved from Swan Song expansion to basegame
- Added to Trial of Infernal Greed drop table

    Ghor's Tome:
- Is now replaced with Ukulele in Trial of Infernal Greed

    Hypo-Threader:
- Improved performance and fixed error spam

    Planula:
- Increased enthusiasm
- Increased burn stack duration against enemies: 5s -> 10s
- Reduced burn stack duration against allies: 5s -> 2s

    Raw Chicken:
- Fixed applying food poisoning twice
- Now clears food poisoning when the item is removed
```

### 1.0.9
```
    Items (General):
- Most new items can now be Ethereal (used in Trials of Winnowing)

    Chimera Scrap:
- No longer spams the log when approaching interactables
```

### 1.0.7
```
    SwanSongExtended:
- Removed a couple of unused hidden items that were causing the mod to fail to load

    Charming Chanterelle:
- Can now be used in Food Related recipes

    Chimera Scrap:
- Now works again

    Hypo-Threader:
- Now respects ProcRate from ProcSolver (does not extend proc chains)

    Raw Chicken:
- Can now be used in Food Related recipes

    Sunken Crown: 
- Now applies curse on interact rather than upon approaching the interactable...
- Reduced "medium" gold threshold: 45 -> 40
- Reduced "big" gold threshold: 245 -> 150
```

### 1.0.6
```
    Reworks (General):
- No longer applies certain reworked item effects while their respective reworks are disabled

    Copper Fork:
- Reduced damage coefficient: 600%+400% -> 300%+300%

    Destroyer Emblem:
- Reduced duration: 4+2s -> 3+1.5s

    Hypo-Threader:
- Changed proc coefficient behavior: 0.35 -> 50% of the attack that procced it

    Kaleidoskull:
- Fixed missing base crit

    Snapping Stone:
- Reduced damage bonus: 900+300% -> 400+250%
```

### 1.0.5
```
    Elites (General):
- Un-lobotomized Elite types now that Elite API is fixed
```

### 1.0.4
```
    SwanSongExtended:
- Added missing DifficultyAPI dependency
- Now works as intended for the Hallowed Concepts update

    Elites (General):
- Some new Elite types will not be able to naturally spawn until the next update, this is waiting on a fix to R2API Elites
- Also, the Elites that do naturally spawn will have the wrong colors, sorry
```

### 1.0.3
```
    SwanSongExtended:
- Added missing NegativeRegenFix dependency
- No longer hard-dependent on NegativeRegenFix
- No longer fails to load if certain items fail their hooks

    Sunken Crown:
- Now steals from chests before spending money
- Reduced steal count: 2+1 => 1+1
```

### 1.0.2
```
    SwanSongExtended:
- Fixed an error that would occur during loading while the Storms section is disabled
- Fixed an error that would occur during loading with certain items if they are disabled through any means
- Added clarification for the configuration names of certain reworked items
- Remove GAH dependency

    Combat Telescope:
- Reduced critical chance bonus while stationary: 40% -> 30%
```

### 1.0.1
```
    Coin Gun:
- Fixed an error that occurs when placing Engineer's turrets

    Charming Chanterelle:
- Fixed text color
```

### 1.0.0
```
    SwanSongExtended:
- Newly Standalone from 2R4R ;3
```

### 0.1.0
```
- Release version
```