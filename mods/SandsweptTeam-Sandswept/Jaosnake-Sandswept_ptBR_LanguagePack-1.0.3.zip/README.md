# 🌍 Jaosnake-Sandswept_ptBR_LanguagePack

![Versão](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-obrigat%C3%B3rio-ff69b4)

Tradução dedicada em **Português (Brasil)** para o mod **Sandswept**, criado por **SandsweptTeam**.

---

### 🇧🇷 Recomendação do P.E.L.E
P.E.L.E é opcional e não é necessário para usar este pacote em português. Para suporte a ucraniano, esperanto e latim, instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/).

---

> O pacote multilíngue também inclui pt-BR; use apenas um dos dois para evitar traduções duplicadas.

## 📦 Dependências
| Pacote | Versão |
|---------|---------|
| SandsweptTeam-Sandswept | `1.4.6` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Idioma Suportado
| Bandeira | Idioma | Código | Tokens |
|:---:|---|:---:|:---:|
| 🇧🇷 | Português (Brasil) | `pt-BR` | 289/289 |

## ✨ Destaques da Tradução Dedicada
- **289 tokens** disponíveis em português brasileiro.
- Correção de bugs de tags herdados do mod original (`<style=cShrine>...</color>` corrigido para `</style>`).
- Sanitização de aspas duplas e formatação de texto em todo o lore (incluindo Red Spring Water).
- Mantém nomes de itens, mecânicas e termos fiéis ao universo do Risk of Rain 2.

## 📥 Instalação Manual
1. Instale **Sandswept** e **R2API_Language**.
2. Baixe este pacote.
3. Copie a pasta `Jaosnake-Sandswept_ptBR_LanguagePack` para `BepInEx/plugins/`.
4. No jogo, selecione **Português (Brasil)** nas opções de idioma.

Este pacote contém apenas arquivos de tradução R2API.Language. Ele não modifica o código do Sandswept.

## 👤 Créditos
| Função | Nome |
|------|------|
| Mod original | [SandsweptTeam](https://thunderstore.io/c/riskofrain2/p/SandsweptTeam/Sandswept/) |
| Tradução pt-BR, revisão e pacote | Jaosnake |

---

## ☕ Apoie
[![ko-fi](https://img.shields.io/badge/Ko--fi-Apoiar-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
