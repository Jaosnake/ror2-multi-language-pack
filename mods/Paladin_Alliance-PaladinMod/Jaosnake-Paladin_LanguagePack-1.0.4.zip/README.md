# 🌍 Jaosnake-Paladin_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.4-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Paladin** by **Paladin_Alliance**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| Paladin_Alliance-PaladinMod | `2.3.2` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 85/85 |
| 🇩🇪 | German | `de` | 85/85 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 85/85 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 85/85 |
| 🇫🇷 | French | `FR` | 85/85 |
| 🇮🇹 | Italian | `IT` | 85/85 |
| 🇯🇵 | Japanese | `ja` | 85/85 |
| 🇰🇷 | Korean | `ko` | 85/85 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 85/85 |
| 🇷🇺 | Russian | `RU` | 85/85 |
| 🇹🇷 | Turkish | `tr` | 85/85 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 85/85 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 85/85 |
| 🟩 | Esperanto | `eo` | 85/85 |
| 🏛️ | Latin | `la` | 85/85 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [Paladin_Alliance](https://thunderstore.io/c/riskofrain2/p/Paladin_Alliance/PaladinMod/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
