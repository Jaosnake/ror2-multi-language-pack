## 1.0.3
- Standardized survivor proper name to "Henry" across all language files to prevent desync.
- Comprehensive grammatical and terminological overhaul across all 13 languages (fixing incorrect obelisk obliteration terms, skill verbal concordances, and machine-translation artifacts in French, German, Italian, Spanish, Russian, Ukrainian, Chinese, Japanese, Korean, Turkish, and pt-BR).
- Fixed pt-BR terminology to match official Risk of Rain 2 standards (obliteration at the Obelisk, Monsoon difficulty, and Mastery achievement).
- Cleaned and strictly balanced all TextMeshPro style and color tags across all files.
- Validated JSON structure and UTF-8 encoding (no BOM) across all 13 translation files.

## 1.0.2
- Fixed mojibake, accent issues, language tokens, and untranslated English fallbacks.
- Rebuilt the R2API.Language package for manual Thunderstore upload.

## 1.0.1
- Fixed credits that were polluting the interface due to an error during file upload.
