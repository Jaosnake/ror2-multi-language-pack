## 1.0.3
- Reviewed all 15 languages against Mortician 0.1.5 and corrected the passive and skill tokens.
- Restored the survivor tips, lore, and keyword descriptions.
- Synchronized both translation file families and corrected formatting.

## 1.0.2
- Fixed mojibake, accent issues, language tokens, and untranslated English fallbacks.
- Rebuilt the R2API.Language package for manual Thunderstore upload.

## 1.0.1
- Fixed credits that were polluting the interface due to an error during file upload.
