# 🇧🇷 Jaosnake-Starstorm2_ptBR_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.4-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Tradução completa para **Português do Brasil (pt-BR)** do mod **Starstorm 2** desenvolvido por **TeamMoonstorm**.

Sincronizado e compatível com **Starstorm 2 v0.6.47** e **R2API_Language**.

---

## Correção de valores dinâmicos

O [MSU Translation Fix](https://thunderstore.io/c/riskofrain2/p/Jaosnake/MSU_Translation_Fix/) é uma dependência instalada automaticamente pelo gerenciador de mods. Ele substitui marcadores como `{0}` e `{1}` pelos valores atuais fornecidos pelo Moonstorm Shared Utils. A correção funciona com R2API.Language e também com P.E.L.E.

Para suporte aos idiomas adicionais e compatibilidade com os pacotes de tradução, recomendamos instalar [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/).

## 📦 Dependências
| Pacote | Versão Mínima |
|---|---|
| TeamMoonstorm-Starstorm2 | `0.6.47` |
| RiskofThunder-R2API_Language | `1.1.0` |
| Jaosnake-MSU_Translation_Fix | `1.0.0` |

---

## 🌐 Conteúdo da Tradução
- **100% dos Itens e Equipamentos** (incluindo o novo item *Balde de Soldadinhos de Brinquedo*).
- **100% das Habilidades e Dicas de Sobreviventes** (Chirr, Commando, Executioner, Nemesis Mercenary, etc.).
- **Fórmulas Dinâmicas Atualizadas**: todas as descrições utilizam os novos placeholders do jogo ({0}, {1}, etc.), garantindo números e escalonamento sempre exatos.
- **Conquistas e Diários**: formatados rigorosamente no padrão oficial do Risk of Rain 2 pt-BR.

---

## 👤 Créditos
| Função | Nome |
|---|---|
| Mod Original | [TeamMoonstorm](https://thunderstore.io/c/riskofrain2/p/TeamMoonstorm/Starstorm2/) |
| Primeira Tradução Base | Kauzok e Balorfist |
| Revisão Linha a Linha & Atualização 0.6.47 | Jaosnake |

---

## ☕ Apoie o Projeto
[![ko-fi](https://img.shields.io/badge/Ko--fi-Apoie%20o%20Projeto-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
