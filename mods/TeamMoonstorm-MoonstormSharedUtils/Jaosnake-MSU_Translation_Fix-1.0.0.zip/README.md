# MSU Translation Fix

Compatibility plugin for translations of mods that use Moonstorm Shared Utils, including Starstorm 2.

Some translated descriptions contain placeholders such as `{0}` and `{1}` for configurable item values. This plugin uses Moonstorm's own format values to fill those placeholders in translations loaded through R2API.Language or P.E.L.E. It does not change the item's mechanics.

The Starstorm 2 language packs declare this package as a dependency. A mod manager installs it automatically. P.E.L.E is optional for this fix; it remains recommended for its extended language support.

This plugin is only active when Moonstorm Shared Utils is installed. The current build was tested with Starstorm 2 0.6.47 and Moonstorm Shared Utils 2.6.3.
