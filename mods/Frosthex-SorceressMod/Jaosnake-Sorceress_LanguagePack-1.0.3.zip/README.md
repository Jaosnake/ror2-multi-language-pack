# 🌍 Jaosnake-Sorceress_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **SorceressMod** by **Frosthex**, reviewed against the original 0.7.5 texts.

> 🇺🇦 Ukrainian language added because original mod does not include it.

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| Frosthex-SorceressMod | `0.7.5` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Languages
| Flag | Language |
|------|----------|
| 🇺🇸 | English |
| 🇩🇪 | German |
| 🇪🇸 | Spanish (LATAM) |
| 🇪🇸 | Spanish (Spain) |
| 🇫🇷 | French |
| 🇮🇹 | Italian |
| 🇯🇵 | Japanese |
| 🇰🇷 | Korean |
| 🇧🇷 | Portuguese (BR) |
| 🇷🇺 | Russian |
| 🇹🇷 | Turkish |
| 🇺🇦 | Ukrainian ⚡ |
| 🇨🇳 | Chinese (Simplified) |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [Frosthex](https://thunderstore.io/c/riskofrain2/p/Frosthex/SorceressMod/) |
| Translations | Jaosnake |
| Original Russian localization | N3xT |
| Original Chinese localization | Taka |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
