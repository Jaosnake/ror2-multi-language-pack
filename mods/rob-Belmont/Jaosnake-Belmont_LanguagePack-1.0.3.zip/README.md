# 🌍 Jaosnake-Belmont_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Belmont** by **rob**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| rob-Belmont | `1.0.10` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 112/112 |
| 🇩🇪 | German | `de` | 112/112 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 112/112 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 112/112 |
| 🇫🇷 | French | `FR` | 112/112 |
| 🇮🇹 | Italian | `IT` | 112/112 |
| 🇯🇵 | Japanese | `ja` | 112/112 |
| 🇰🇷 | Korean | `ko` | 112/112 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 112/112 |
| 🇷🇺 | Russian | `RU` | 112/112 |
| 🇹🇷 | Turkish | `tr` | 112/112 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 112/112 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 112/112 |
| 🟩 | Esperanto | `eo` | 112/112 |
| 🏛️ | Latin | `la` | 112/112 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [rob](https://thunderstore.io/c/riskofrain2/p/rob/Belmont/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
