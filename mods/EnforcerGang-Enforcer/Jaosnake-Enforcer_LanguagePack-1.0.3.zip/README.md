# 🌍 Jaosnake-Enforcer_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Enforcer** by **EnforcerGang**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| EnforcerGang-Enforcer | `3.11.10` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 144/144 |
| 🇩🇪 | German | `de` | 144/144 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 144/144 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 144/144 |
| 🇫🇷 | French | `FR` | 144/144 |
| 🇮🇹 | Italian | `IT` | 144/144 |
| 🇯🇵 | Japanese | `ja` | 144/144 |
| 🇰🇷 | Korean | `ko` | 144/144 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 144/144 |
| 🇷🇺 | Russian | `RU` | 144/144 |
| 🇹🇷 | Turkish | `tr` | 144/144 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 144/144 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 144/144 |
| 🟩 | Esperanto | `eo` | 144/144 |
| 🏛️ | Latin | `la` | 144/144 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [EnforcerGang](https://thunderstore.io/c/riskofrain2/p/EnforcerGang/Enforcer/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
