# 🌍 Jaosnake-Starstorm2_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-2.0.4-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Starstorm2** by **TeamMoonstorm**.

> ⚠️ pt-BR is NOT included in this pack. pt-BR was manually translated by Jaosnake and is available separately.

> 🇺🇦 Ukrainian is included in this pack. To enable it as a selectable in-game language, install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/), where Ukrainian is supported natively.

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| TeamMoonstorm-Starstorm2 | `0.6.46` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Languages
| Flag | Language |
|------|----------|
| 🇺🇸 | English |
| 🇩🇪 | German |
| 🇪🇸 | Spanish (LATAM) |
| 🇪🇸 | Spanish (Spain) |
| 🇫🇷 | French |
| 🇮🇹 | Italian |
| 🇯🇵 | Japanese |
| 🇰🇷 | Korean |
| 🇷🇺 | Russian |
| 🇹🇷 | Turkish |
| 🇺🇦 | Ukrainian ⚡ |
| 🇨🇳 | Chinese (Simplified) |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [TeamMoonstorm](https://thunderstore.io/c/riskofrain2/p/TeamMoonstorm/Starstorm2/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
