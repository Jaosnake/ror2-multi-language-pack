# 🌍 Jaosnake-MinerUnearthed_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **MinerUnearthed** by **EnforcerGang**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| EnforcerGang-MinerUnearthed | `1.10.1` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 76/76 |
| 🇩🇪 | German | `de` | 76/76 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 76/76 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 76/76 |
| 🇫🇷 | French | `FR` | 76/76 |
| 🇮🇹 | Italian | `IT` | 76/76 |
| 🇯🇵 | Japanese | `ja` | 76/76 |
| 🇰🇷 | Korean | `ko` | 76/76 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 76/76 |
| 🇷🇺 | Russian | `RU` | 76/76 |
| 🇹🇷 | Turkish | `tr` | 76/76 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 76/76 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 76/76 |
| 🟩 | Esperanto | `eo` | 76/76 |
| 🏛️ | Latin | `la` | 76/76 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [EnforcerGang](https://thunderstore.io/c/riskofrain2/p/EnforcerGang/MinerUnearthed/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
