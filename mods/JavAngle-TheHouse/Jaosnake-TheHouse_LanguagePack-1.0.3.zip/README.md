# 🌍 Jaosnake-TheHouse_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **TheHouse** by **JavAngle**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| JavAngle-TheHouse | `2.3.3` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 130/130 |
| 🇩🇪 | German | `de` | 130/130 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 130/130 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 130/130 |
| 🇫🇷 | French | `FR` | 130/130 |
| 🇮🇹 | Italian | `IT` | 130/130 |
| 🇯🇵 | Japanese | `ja` | 130/130 |
| 🇰🇷 | Korean | `ko` | 130/130 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 130/130 |
| 🇷🇺 | Russian | `RU` | 130/130 |
| 🇹🇷 | Turkish | `tr` | 130/130 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 130/130 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 130/130 |
| 🟩 | Esperanto | `eo` | 130/130 |
| 🏛️ | Latin | `la` | 130/130 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [JavAngle](https://thunderstore.io/c/riskofrain2/p/JavAngle/TheHouse/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
