## Credits
- borbo…..lead design & programming, icons
- orange_peel…..design, programming, lore, placeholder models
- plnk…..lore, quality assurance
- Leafy…..retiered item icons
- anartoast…..quality assurance
- dotflare…..item models

THIS MOD WAS MADE ENTIRELY BY HUMANS AND IT WILL FOREVER REMAIN THAT WAY. GENERATIVE AI HAS NO PLACE IN OUR CREATIVE PROCESS. THAT IS A RAINROT GUARANTEE!

## Swan Song, Death Comes…

SwanSongExtended is a large-scale content mod featuring dozens of new items, elites, artifacts, interactables, events, a new difficulty level, and a plethora of secrets! As a part of [2R4R, an omnimod project](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/2R4R/), our goal is always to improve the overall game experience. As such, the contents of this mod will sometimes be spread throughout several expansions (not just the Swan Song expansion), and some of it functionally replaces vanilla content (this is referred to as a “rework,” but it's essentially a new item wearing the skin of an older one). 

The core feature of the Swan Song expansion is our new Storms: Timed events that will occur on each stage, adding additional pressure to play resourcefully and put your skills to the test. Packaged with it comes two additional features: the Wishbone, a scavenger hunt-type objective with the prospect of great rewards, ending when the Storm begins; and Storm Elites, a new extra-threatening set of Elite types who are violent manifestations of the Storm itself, terrorizing those who dare not to take shelter from the Storm. Read more on our [wiki tab](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/2R4R/wiki), or throw yourself into the fray and learn about it firsthand!

Everything contained within SwanSongExtended can easily be disabled through configuration, including features we expect some to find controversial like our item reworks and Storms. 

## More Is Along The Way!
In addition to the host of new toys the mod already adds, we want to guarantee that SwanSongExtended will continue to receive updates, including bug fixes AND new content! At the moment, we already have plans for:
- A new Alternate Gamemode
- A new Item Tier
- 3+ new Elite Types
- And More!

Stay tuned for these updates!

## Contents Overview
To help you brave the Storms, Swan Song comes packaged with over 40 of our finest Items and Equipment (60+ if you include Reworks). This includes void variants for new and old items! Every item is carefully crafted to enhance your run, no matter the survivor or build – we don’t believe in “scrapper fuel” here. Don’t be deceived, even the weakest items are more than meets the eye!

Swan Song has everything from good old fashioned crit-synergies to entirely new niches. The Hypo-Threader offers a new source of crowd control for high-crit builds, but for a bleed build, the Copper Fork might be just as appealing with its added stun. Become an immovable object with the stationary items, Slumbering Spores and Cobalt Shield. Don’t go down without a fight with The New Lopper in hand, and make it out alive with a Frozen Turtle Shell.

Worried about item bloat? Don’t be! Swan Song takes extra care to ensure that the spirit of the game is not lost. Find a printer on every stage to reap the powerful bonuses of the iconic Photograph. Return to tri-shops with a Loyalty Card for cash back and even more items. Take a chance on a Champion for their Trophy with the consumable Obsidian Scalpel. And for the opportunistic, the Wishbone can give you a choice for your Teleporter reward on every stage.

Those who are daring enough may even turn their eye to Swan Song’s bizarre and plentiful Lunar Items. Don a Star Veil and discover the meaning of “hubris.” Abandon the light of attack speed with a Compression Loop, and use a Starfire Brand to set the world ablaze. 

… these 13 items are only scratching the surface! The full effects of everything added, including other features like our interactables and Elites, are available to read about on our [wiki](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/2R4R/wiki). But wouldn’t it be more fun to ignore it and reap the joy of discovery? 

## Recommended Mods 
Since SwanSongExtended is built in tandem with [2R4R](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/2R4R/), that is obviously the mod we recommend the most! However, it is not a necessity, though if you do not have 2R4R installed then you will almost certainly want something like [EarlySpawnBoost](https://thunderstore.io/c/riskofrain2/p/Nuxlar/EarlySpawnBoost/) or [DirectorRework+](https://thunderstore.io/c/riskofrain2/p/score/DirectorReworkPlus/) to improve the pacing of enemy spawns in the first few stages.

Other Recommended Mods
- [ProcSolver](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/ProcSolver/): Normalizes on-hit chance behavior, improves performance
- [WolfFixes](https://thunderstore.io/c/riskofrain2/p/Wolfo/WolfFixes/): Numerous bug fixes i like :]
- [PartialInventorySortSystem](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/PartialInventorySortSystem/): Lightweight sorting of Quest and Scrap items for easier inventory management
- [CommandMenuResizer](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/CommandMenuResizer/): Lightweight expansion of the Command menu
- [FruityBossDrop](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/FruityBossDrop/): Overhaul for Trophy Item acquisition. Has explicit synergy with Obsidian Scalpel
- [FruityCradles](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/FruityCradles/): Increases choice and counteracts void item advantage
- [FruityAspectsGaming](https://thunderstore.io/c/riskofrain2/p/RiskOfBrainrot/FruityAspectsGaming/): Elite reworks to match the quality of elites introduced in SwanSongExtended

## We Want Your Feedback!
Want something added or changed? Join our [Discord Server](https://discord.gg/w5QBHx5WNP)!

Found a bug? Submit it through [GitHub](https://github.com/bbborbo/RiskierRain/) or the support channel in our server! 

Love the mod? Tell a streamer about it ;3

# <3
