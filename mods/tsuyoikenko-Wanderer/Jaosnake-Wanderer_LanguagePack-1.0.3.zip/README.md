# 🌍 Jaosnake-Wanderer_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Wanderer** by **tsuyoikenko**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| tsuyoikenko-Wanderer | `1.0.1` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 21/21 |
| 🇩🇪 | German | `de` | 21/21 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 21/21 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 21/21 |
| 🇫🇷 | French | `FR` | 21/21 |
| 🇮🇹 | Italian | `IT` | 21/21 |
| 🇯🇵 | Japanese | `ja` | 21/21 |
| 🇰🇷 | Korean | `ko` | 21/21 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 21/21 |
| 🇷🇺 | Russian | `RU` | 21/21 |
| 🇹🇷 | Turkish | `tr` | 21/21 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 21/21 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 21/21 |
| 🟩 | Esperanto | `eo` | 21/21 |
| 🏛️ | Latin | `la` | 21/21 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [tsuyoikenko](https://thunderstore.io/c/riskofrain2/p/tsuyoikenko/Wanderer/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
