## 1.0.3
- Sincronização completa com a versão mais recente do Starstorm 2 (v0.6.46) totalizando 1.213 tokens.
- Adicionados os novos tokens da versão 0.6.46: item *Balde de Soldadinhos de Brinquedo* (Bucket of Toy Soldiers), skins de Chirr (*Isópode*) e Commando (*Especialista*), conquistas correspondentes, habilidade *Lança Sísmica* e *Barril de Segurança*.
- Atualizados todos os tokens com fórmulas dinâmicas ({0}, {1}, etc.) para garantir compatibilidade com o novo rebalanceamento de estatísticas.
- Revisão completa de gramática, ortografia e pontuação de acordo com os termos oficiais do Risk of Rain 2 em pt-BR.
- Balanceamento estrito de tags do Unity TextMeshPro (<style>, <color>) e codificação UTF-8 pura sem BOM.

## 1.0.2
- Revisão de termos e compatibilidade com versões anteriores.

## 1.0.1
- Correção de erros ortográficos e tags ausentes.

## 1.0.0
- Lançamento inicial da tradução em pt-BR do Starstorm 2.
