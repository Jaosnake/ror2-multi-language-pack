# 🌍 Jaosnake-Mortician_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Mortician** by **Bog**, reviewed against the original mod version 0.1.5.

> Ukrainian, Esperanto and Latin are included. P.E.L.E. provides support for these language options.

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| Bog-Mortician | `0.1.5` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Languages
| Flag | Language |
|------|----------|
| 🇺🇸 | English |
| 🇩🇪 | German |
| 🇪🇸 | Spanish (LATAM) |
| 🇪🇸 | Spanish (Spain) |
| 🇫🇷 | French |
| 🇮🇹 | Italian |
| 🇯🇵 | Japanese |
| 🇰🇷 | Korean |
| 🇧🇷 | Portuguese (BR) |
| 🇷🇺 | Russian |
| 🇹🇷 | Turkish |
| 🇺🇦 | Ukrainian |
| 🇨🇳 | Chinese (Simplified) |
| 🌐 | Esperanto |
| 🏛️ | Latin |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [Bog](https://thunderstore.io/c/riskofrain2/p/Bog/Mortician/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)


## Issues / Feedback
For translation issues or suggestions, open a ticket at https://github.com/Jaosnake/ror2-multi-language-pack/issues

> **Note**: Game loading times may increase slightly as additional language packs are processed during startup.
