## 2.0.5
- Update compatibility to Starstorm 2 0.6.47.
- Add MSU Translation Fix as a dependency for dynamic description values.
- Update documentation and standard package icon.

## 2.0.4
- Synchronized package with the latest Starstorm 2 release (v0.6.46).
- Added 22 brand new translation tokens (Bucket of Toy Soldiers, Chirr/Commando skins, Chirr/Commando achievements, Tactical Leap, Seismic Spear, Security Barrel).
- Updated 64 dynamic placeholder tokens ({0}, {1}) across all languages to reflect official item/equipment stat formula reworks.
- Fixed Issue #1: Corrected unclosed style tag in Russian Typhoon difficulty description (SS2_DIFFICULTY_TYPHOON_DESC).
- Comprehensive audit across all 12 supported language files, ensuring UTF-8 without BOM, strict JSON validity, and 100% balanced TextMeshPro tags.

## 2.0.3
- Updated to stay in sync with the latest StarStorm2 version.

## 2.0.2
- After an extensive audit, the package was updated across all supported languages.
- Added Ukrainian to the package; another mod is required to enable it in-game. Read the README for more information.

## 2.0.1
- Updated package version to continue from the published Thunderstore 2.0.0 release.
- Keeps the current multi-language translation fixes and R2API.Language package structure.

## 1.0.2
- Fixed mojibake, accent issues, language tokens, and untranslated English fallbacks.
- Rebuilt the R2API.Language package for manual Thunderstore upload.

## 1.0.1
- Fixed credits that were polluting the interface due to an error during file upload.
