# 🌍 Jaosnake-Sandswept_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Sandswept** by **SandsweptTeam**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

> The multilingual package includes pt-BR; use either this package or the dedicated pt-BR package to avoid duplicate translations.

## 📦 Dependencies
| Package | Version |
|---------|---------|
| SandsweptTeam-Sandswept | `1.4.6` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 289/289 |
| 🇩🇪 | German | `de` | 289/289 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 289/289 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 289/289 |
| 🇫🇷 | French | `FR` | 289/289 |
| 🇮🇹 | Italian | `IT` | 289/289 |
| 🇯🇵 | Japanese | `ja` | 289/289 |
| 🇰🇷 | Korean | `ko` | 289/289 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 289/289 |
| 🇷🇺 | Russian | `RU` | 289/289 |
| 🇹🇷 | Turkish | `tr` | 289/289 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 289/289 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 289/289 |
| 🟩 | Esperanto | `eo` | 289/289 |
| 🏛️ | Latin | `la` | 289/289 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [SandsweptTeam](https://thunderstore.io/c/riskofrain2/p/SandsweptTeam/Sandswept/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
