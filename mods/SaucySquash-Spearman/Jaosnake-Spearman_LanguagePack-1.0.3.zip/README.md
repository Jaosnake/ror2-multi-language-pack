# 🌍 Jaosnake-Spearman_LanguagePack

![Version](https://img.shields.io/badge/%F0%9F%97%82%EF%B8%8F%20Version-1.0.3-blue)
![R2API](https://img.shields.io/badge/%F0%9F%93%A6%20R2API__Language-required-ff69b4)

Multi-language translation pack for **Spearman** by **SaucySquash**.

---

### 🇧🇷 Recomendação do P.E.L.E
O P.E.L.E é opcional. Instale [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) para jogar em ucraniano (UA), esperanto (eo) ou latim (la).

### 🇺🇸 P.E.L.E Recommendation
P.E.L.E is optional. Install [P.E.L.E](https://thunderstore.io/c/riskofrain2/p/Jaosnake/PELE/) to play in Ukrainian (UA), Esperanto (eo), or Latin (la).

---

## 📦 Dependencies
| Package | Version |
|---------|---------|
| SaucySquash-Spearman | `1.0.7` |
| RiskofThunder-R2API_Language | `1.1.0` |

## 🌐 Supported Languages (15)
| Flag | Language | Code | Tokens |
|:---:|---|:---:|:---:|
| 🇺🇸 | English | `en` | 30/30 |
| 🇩🇪 | German | `de` | 30/30 |
| 🇪🇸 | Spanish (LATAM) | `es-419` | 30/30 |
| 🇪🇸 | Spanish (Spain) | `es-ES` | 30/30 |
| 🇫🇷 | French | `FR` | 30/30 |
| 🇮🇹 | Italian | `IT` | 30/30 |
| 🇯🇵 | Japanese | `ja` | 30/30 |
| 🇰🇷 | Korean | `ko` | 30/30 |
| 🇧🇷 | Portuguese (BR) | `pt-BR` | 30/30 |
| 🇷🇺 | Russian | `RU` | 30/30 |
| 🇹🇷 | Turkish | `tr` | 30/30 |
| 🇺🇦 | Ukrainian ⚡ | `UA` | 30/30 |
| 🇨🇳 | Chinese (Simplified) | `zh-CN` | 30/30 |
| 🟩 | Esperanto | `eo` | 30/30 |
| 🏛️ | Latin | `la` | 30/30 |

## 👤 Credits
| Role | Name |
|------|------|
| Original Mod | [SaucySquash](https://thunderstore.io/c/riskofrain2/p/SaucySquash/Spearman/) |
| Translations | Jaosnake |

---

## ☕ Support
[![ko-fi](https://img.shields.io/badge/Ko--fi-Support%20Me-%23FF5E5B?logo=ko-fi)](https://ko-fi.com/jaosnake)
