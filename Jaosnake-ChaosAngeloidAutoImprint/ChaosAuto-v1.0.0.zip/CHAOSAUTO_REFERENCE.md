# ChaosAuto - Auto Imprint para ChaosAngeloid

## Objetivo
Fazer o 5º skill do ChaosAngeloid (Imprint / "Minion, Arise!") funcionar automaticamente — sem apertar F. Quando um inimigo morre perto do jogador, ele revive automaticamente como um aliado por 3 minutos, com brilho roxo (TemporaryOverlayBehaviour + masterHighlight), boost de 10% (HP, velocidade, ataque), e sistema de fila por tipo.

---

## Arquivos

| Arquivo | Caminho |
|---------|---------|
| Código fonte | `C:\Users\Jaosnake\AppData\Local\Temp\opencode\ChaosAngeloidAutoImprint.cs` |
| .csproj (build) | `C:\Users\Jaosnake\AppData\Local\Temp\opencode\ChaosAuto.csproj` |
| DLL compilada | `C:\Users\Jaosnake\AppData\Local\Temp\opencode\bin\Release\netstandard2.1\ChaosAuto.dll` |
| DLL no jogo | `...\BepInEx\plugins\Jaosnake-ChaosAngeloidAutoImprint\ChaosAuto.dll` |
| Manifest | `...\BepInEx\plugins\Jaosnake-ChaosAngeloidAutoImprint\manifest.json` |
| Log do jogo | `...\BepInEx\LogOutput.log` |
| Decompile | `C:\Users\Jaosnake\AppData\Local\Temp\opencode\chaos_decompiled.txt` |
| Asset bundle | `C:\Users\Jaosnake\AppData\Local\Temp\opencode\next10_unpack\blobs\ChaosAngeloid.blob` |
| Assemblies do jogo | `D:\SteamLibrary\steamapps\common\Risk of Rain 2\Risk of Rain 2_Data\Managed\` |
| BepInEx core | `...\cache\bbepis-BepInExPack\5.4.2121\BepInExPack\BepInEx\core\` |

---

## Compilação

```powershell
dotnet build "C:\Users\Jaosnake\AppData\Local\Temp\opencode\ChaosAuto.csproj" -c Release
Copy-Item "C:\Users\Jaosnake\AppData\Local\Temp\opencode\bin\Release\netstandard2.1\ChaosAuto.dll" "...\BepInEx\plugins\Jaosnake-ChaosAngeloidAutoImprint\ChaosAuto.dll" -Force
```

---

## Arquitetura do Código Atual

### `ChaosAngeloidAutoImprintPlugin` (BepInPlugin)
- Hook `On.RoR2.CharacterBody.Start` no Awake
- Verifica se o body tem `ChaosAngeloid.Behaviour` via `HasChaosBehaviour()`
- Adiciona `AutoImprintBehaviour` no jogador

### `ResurrectedMinion` (MonoBehaviour)
- Tag component vazio — identifica corpos que já foram ressuscitados
- Usado no `OnEnemyDeath` pra evitar re-queue (anti-loop)

### `AutoImprintBehaviour` (MonoBehaviour)
**Campos de reflection:**
- `fiMaster` → `ChaosAngeloid.Behaviour.master`
- `masterMarkBuff` → `ChaosAngeloid.Prefabs.masterMarkBuff` (BuffDef)
- `tempOverlayType` → `ChaosAngeloid.TemporaryOverlayBehaviour`
- `tempOverlayTemporary` → field `temporary` (bool)
- `addOverlayMethod` → method `AddOverlay(Material)`
- `masterHighlight` → `ChaosAngeloid.Prefabs.masterHighlight` (Material)

**Fluxo `OnEnemyDeath()`:**
1. Filtros: null, player, champion, boss, player team, já-ressuscitado (`ResurrectedMinion`), fora do range (25m)
2. Lista negra: ignora `BeetleBody`, `WispBody`
3. Sem aliado vivo:
   - Se `respawnDelay <= 0` E fila vazia → `SpawnMinion()` imediato
   - Caso contrário → vai pra fila
4. Aliado vivo + mesmo tipo → skip
5. Fila cheia → smart replace (substitui o aliado mais fraco por elite)

**Fluxo `FixedUpdate()`:**
1. Aliado vivo: verifica se morreu (respawnDelay = 5s), expirou (KillAlly + delay), ou atualiza master
2. Sem aliado: se `respawnDelay > 0`, decrementa; quando chega a 0 → `SpawnFromQueue()`
3. Sem aliado + sem delay → `SpawnFromQueue()`

**Fluxo `SpawnMinion(GameObject prefab, CharacterMaster victimMaster, bool isElite)`:**
1. MasterSummon com `teamIndexOverride = Player`, `summonerBodyObject = jogador`
2. `MinionLeash` item
3. **Cópia de equipamento elite**: se `isElite`, copia `currentEquipmentIndex` + `alternateEquipmentIndex` do `victimMaster`
4. Boost 10%: `baseMaxHealth`, `baseMoveSpeed`, `baseAttackSpeed`
5. Reset health: `hc.health = hc.fullCombinedHealth`
6. `ResurrectedMinion` component
7. `masterMarkBuff` (buff do brilho roxo via HUD)
8. `TemporaryOverlayBehaviour` + `masterHighlight` (glow roxo no modelo 3D)
9. BaseAI ativado (followPattern 2-10m, enemyAttentionDuration 6s, fullVision false, maxDistance 130m)
10. allyTimer = 180s
11. `allyIsEliteStatus` atualizado com `isElite` (detectado via `IsEliteEnemy(master)`, não `vb.isElite`)

**Refatoração (v4 — código modular):**
- **`IsEliteEnemy(CharacterMaster)`**: detecta elite pelo inventory (confiável, não `vb.isElite`)
- **`IsValidVictim()`**: filtros de morte extraídos pra método único
- **`TrySmartReplace(GameObject, CharacterMaster, bool)`**: substituição inteligente
- **`SweepDeadAllies()`**: varredura de aliados mortos/expirados
- **`CheckSlotAvailability()`**: verificação de slot (canSpawn, movementSlotFull, sameTypeAsAny)
- **`FindWeakestNonEliteAllyIndex()`**: encontra aliado normal mais fraco
- **`RemoveAllyAt()`**: helper para remoção consistente de aliados
- **`FireMasterSkill(CharacterBody)`**: executa PickMaster
- Código ~460 linhas

---

## Histórico de Problemas e Soluções

### 1. FieldAccessException: `body.transform` inacessível
- **Sintoma**: `FieldAccessException: Field RoR2.CharacterBody:transform' is inaccessible`
- **Causa**: Código ofuscado do RoR2 esconde `transform`
- **Solução**: Substituiu `body.transform.forward` por `body.characterDirection.forward`

### 2. Minion morria imediatamente após SpawnBody
- **Sintoma**: Log `Ally spawned successfully` seguido de morte no mesmo frame
- **Causa**: `selected.SpawnBody()` reusa um CharacterMaster morto com estado de morte
- **Solução final**: `MasterSummon` cria master NOVO do prefab (`MasterCatalog.GetMasterPrefab`)

### 3. Loop infinito de re-queue do mesmo mob
- **Sintoma**: Mesmo besouro ressuscitado → morria → re-enfileirado → loop
- **Causa**: OnCharacterDeathGlobal pegava a morte do minion e re-enfileirava
- **Solução**: `ResurrectedMinion` component tag → OnEnemyDeath ignora

### 4. Brilho roxo sem efeito (só masterMarkBuff não bastava)
- **Sintoma**: masterMarkBuff adicionado mas sem glow no modelo 3D
- **Causa**: O buff só dá o ícone roxo no HUD. O glow visual vem do `TemporaryOverlayBehaviour` com `masterHighlight`
- **Solução**: Adicionou `TemporaryOverlayBehaviour` com `masterHighlight` via reflection

### 5. Minions muito fracos
- **Sintoma**: Minions morriam rápido demais
- **Solução**: Boost de 10% em `baseMaxHealth`, `baseMoveSpeed`, `baseAttackSpeed`

### 6. Delay entre minions
- **Sintoma**: Aliado morria e o próximo spawnava instantaneamente
- **Solução**: `respawnDelay = 5s` entre morte e próximo spawn

### 7. NullReferenceException ao iniciar o mod (Language.english nulo)
- **Sintoma**: `NullReferenceException` no `Awake()` → `Language.english.SetStringByToken`
- **Causa**: `Language.english` não está disponível no `Awake()` do plugin BepInEx
- **Solução**: Moveu tooltip pro `Start()` com null check `if (Language.english != null)`

### 8. Smart Replace passava victimBody errado (Bug de Auditoria)
- **Sintoma**: Elite novo era rastreado como não-elite em `allyIsEliteStatus`
- **Causa**: `SpawnMinion(prefab, oldAlly)` passava o minion morrendo (não-elite) como `victimBody`
- **Solução**: `TrySmartReplace` agora recebe `CharacterBody victimBody` original do elite morto

### 9. Código morto no `HandleSpawnOrQueueOrReplace` (Bug de Auditoria)
- **Sintoma**: Método com 40% de código nunca executado
- **Causa**: Verificação de slot duplicada — `OnEnemyDeath` já spawnava antes de chamar o método
- **Solução**: Método removido, lógica de fila/replace movida direto pro `OnEnemyDeath`

### 10. `CheckSlotAvailability` com parâmetro redundante (Auditoria)
- **Solução**: Removeu parâmetro `alliesList` — usa `this.allies` direto da instância

---

## Sistema de Fila

| Estado | Ação |
|--------|------|
| Sem aliado, sem delay, fila vazia | `SpawnMinion()` imediato no próximo morte |
| Sem aliado, delay ativo | Morte vai pra fila (slot 2) |
| Aliado vivo, tipo diferente | Vai pra fila (slot 2) |
| Fila cheia (1 slot) | Skip → `TrySmartReplace()` (substitui o aliado mais fraco por elite) |
| Aliado morre | `respawnDelay = 5s` |
| Delay expira | `SpawnFromQueue()` |

## Prioridade e Substituição Inteligente

**Prioridade (Elite > Normal):**
- Elite (`isElite == true`) sempre tem prioridade sobre aliados normais
- Se um candidato elite aparece e há um slot livre, ele spawna imediatamente
- Elite minions são rastreados em `allyIsEliteStatus` para prioridade decisions

**Smart Replace:**
- Quando fila cheia e um novo candidato elite aparece:
  - O **aliado mais fraco (normal)** é substituído com o novo elite
  - O aliado antigo é morto via `KillAlly()` (dispara suicídio + limpeza)
  - O novo elite spawna em seu lugar
- **Log**: `[ChaosAuto] Replaced weak ally with elite: <prefab.name>`

**Blacklist:**
- `BeetleBody`, `WispBody` são ignorados completamente (não entram no pool)
- Aplicado antes da prioridade e da substituição inteligente

---

## Decompile: Arquitetura do ChaosAngeloid.dll

### Classes Relevantes

| Classe | Função |
|--------|--------|
| `Behaviour` | Componente no jogador. Campo `master` (CharacterBody alvo) |
| `PickMaster` | EntityState do F skill. Adiciona `MasterMarkBehaviour` + `TemporaryOverlayBehaviour` no alvo |
| `MasterMarkBehaviour` | Aplica `masterMarkBuff`, overlay, transfere 10% stats do dono pro alvo |
| `TemporaryOverlayBehaviour` | Overlay visual. `AddOverlay(Material)`, campo `temporary` (bool) |
| `Prefabs` | `masterMarkBuff` (BuffDef), `masterHighlight` (Material roxo), `allyHighlight` (Material azul) |
| `EntityScanBehaviour` | Scan passivo 45m com BullseyeSearch |

### PickMaster (F skill)
```csharp
behaviour.master = behaviour.targetHurtbox.healthComponent.body;
((Component)behaviour.master).gameObject.AddComponent<MasterMarkBehaviour>().owner = player;
((Component)behaviour.master).gameObject.AddComponent<TemporaryOverlayBehaviour>();
temporaryOverlayBehaviour.temporary = false;
temporaryOverlayBehaviour.AddOverlay(Prefabs.masterHighlight);
```

### Hook de Dano (20% bonus)
```csharp
if (self.body.HasBuff(Prefabs.masterDmgBuff) && damageInfo.attacker.GetComponent<MasterMarkBehaviour>())
{
    damageInfo.damage *= 1.2f;
}
```

---

## Referência: MasterSummon

```csharp
MasterSummon summon = new MasterSummon
{
    masterPrefab = prefab,
    position = spawnPos,
    rotation = Quaternion.identity,
    summonerBodyObject = body.gameObject,
    teamIndexOverride = TeamIndex.Player,
    ignoreTeamMemberLimit = false,
    inventoryToCopy = body.inventory
};
CharacterMaster newMaster = summon.Perform();
```

---

## Notas

- Classes do ChaosAngeloid.dll são `internal` — acessadas via `Assembly.GetType()` + reflection
- `masterHighlight` usa remap texture `texBehemothRamp.png` (vermelho/roxo), FresnelPower 0.66, AlphaBoost 6
- Nenhum mod no Thunderstore faz exatamente o mesmo sistema (hook de morte + MasterSummon + fila + glow)
- RalseiSurvivor é o mais próximo: skill "Pacify" converte inimigos <50% HP em aliados (max 3)
- `SCAN_RADIUS = 25f` — o `EntityScanBehaviour` do mod original usa 45m se quiser alinhar

---

## Atualizações Recentes (v2)

### 2 aliados simultâneos + Divisão Terrestre/Voador
- `MAX_ALLIES = 2`: suporta até 2 minions vivos ao mesmo tempo
- **1 slot terrestre** + **1 slot voador**: baseado em `CharacterBody.isFlying`
- Se o slot de movimento já está ocupado → vai pra fila (se houver vaga)
- **Tipo diverso**: mesmo `GetBodyType()` não duplica entre aliados vivos

### AI Ativada (antiga: `ai.enabled = false`)
- `SetBaseAIEnabled(true)` via reflection + `leader.gameObject = player`
- `followPattern` 2-10m de distância do jogador
- `enemyAttentionDuration = 6s` — reavalia alvo a cada 6s
- `fullVision = false` — não vê atrás
- `AISkillDriver.maxDistance` capped em **130m**
- Minions usam as próprias skills (AISkillDriver nativo do prefab)

### PickMaster Automático (F skill)
- **1ª marca**: 5s após o primeiro minion spawnar → `TriggerFirstPickMaster()`
- **Seguintes**: `AutoCastPickMaster()` a cada 30s (cooldown da skill) escolhe **aleatoriamente** entre minions sem marca
- Usa `behaviour.masterSkill` (NÃO `skillLocator.special` — que é a R)
- Seta `behaviour.targetHurtbox = ally.mainHurtBox` antes de executar
- 0.7s depois → `RefreshMinionGlows()` (re-aplica glow após PickMaster destruir o Tob)
- **Novo nome**: `Auto Imprint` (em vez de `Imprint`)
- **Nova descrição**: `<style=cIsDamage>Auto</style>. Automatically imprints an unmarked ally every <style=cIsUtility>30s</style>, granting <style=cIsDamage>10% stats</style>.`

### Glow por Estado (Laranja ↔ Vermelho)
- **masterHighlight (laranja)**: minion **sem** `MasterMarkBehaviour`
- **masterHighlight + _TintColor vermelho**: minion **com** `MasterMarkBehaviour`
- Parâmetros atuais:
  - `_AlphaBoost = 6` (reduzido de 10)
  - `_FresnelPower = 0.66` (aumentado de 0.4)
  - Vermelho: `_TintColor = Color(1, 0, 0, 0.3)`
- `RefreshMinionGlows()` roda a cada 1s no FixedUpdate + após PickMaster

### Elite Equipment
- Elite detectado via `IsEliteEnemy(master)` — verifica `master.inventory.currentEquipmentIndex != None`
- `SpawnMinion` copia `currentEquipmentIndex` + `alternateEquipmentIndex` do `victimMaster` pro minion
- Minions elite mantêm buffs visuais (fogo, gelo, elétrico, etc.)

### Prioridade de Elite
- `isElite` é rastreado em `allyIsEliteStatus` para cada minion
- Elite sempre tem prioridade sobre minions normais
- Smart replace substitui normal por elite quando fila cheia

### Reflection
| Campo | Uso |
|-------|-----|
| `fiMaster` | `Behaviour.master` — alvo atual do PickMaster |
| `fiTargetHurtbox` | `Behaviour.targetHurtbox` — setar antes de executar a skill |
| `masterMarkType` | `MasterMarkBehaviour` — checar se minion já tem a marca |
| `masterMarkOwner` | `MasterMarkBehaviour.owner` — setar dono da marca |
| `masterMarkBuff` | `Prefabs.masterMarkBuff` — buff do HUD |
| `overlayType` | `TemporaryOverlayBehaviour` — glow 3D |
| `overlayTemporary` | `TemporaryOverlayBehaviour.temporary` |
| `overlayAddMethod` | `TemporaryOverlayBehaviour.AddOverlay(Material)` |
| `overlayMaterial` | `Prefabs.masterHighlight` — material base do glow |

### Logs de Debug
- `[ChaosAuto] Spawning: ... [ELITE] fly=True/False` — spawn imediato (com tag elite se for o caso)
- `[ChaosAuto] Queued: ... fly=True/False` — fila por delay/outro motivo
- `[ChaosAuto] Ally died, X remaining, 5s delay` — morte de aliado
- `[ChaosAuto] Spawning from queue: ...` — spawn vindo da fila
- `[ChaosAuto] Replaced weak ally with: ...` — smart replace

---

## Testes Recentes (16/06/2026)

### Funcionando ✅
- **Blacklist**: BeetleBody e WispBody ignorados corretamente
- **Spawn de Lemurians**: primeiro kill funciona, slots ground/flying ok
- **Timer 180s**: minions expiram no tempo correto
- **Range 25m**: só ressuscita o que morreu DENTRO do range (não escaneia corpos antigos)
- **Mod nao trava mais**: removido Language.english que causava crash no boot

### Testando / Aguardando confirmação ⏳
- **Elite equipment**: corrigido — agora copia `currentEquipmentIndex` e `alternateEquipmentIndex`
- **Smart Replace**: corrigido — agora detecta elite via `IsEliteEnemy(master)` em vez de `vb.isElite`
- **Glow**: laranja (sem marca) / vermelho (com marca)

### Comportamento conhecido
- Só 2 minions vivos: 1 ground + 1 flying
- Se ambos slots cheios, proximo vai pra fila (1 slot)
- Fila cheia + elite morre → substitui o aliado normal mais fraco
- Se matar rapido demais, algumas mortes sao ignoradas (slots cheios + fila cheia)

---

## Correções da Auditoria (16/06/2026)

### Bug 7: Crash no boot (Language.english nulo → freeze 6% loading)
- **Causa**: `Language.english.SetStringByToken` no `Start()` do plugin rodava durante boot do BepInEx
- **Solução**: Removido completamente. Tooltip cosmético não vale o risco de crash

### Bug 8: Elite sem poderes visuais
- **Sintoma**: Elite ressuscitado não tinha fogo/gelo/etc
- **Causa**: Código de cópia de `currentEquipmentIndex` e `alternateEquipmentIndex` foi perdido na refatoração
- **Solução**: Adicionado bloco em `SpawnMinion`:
  ```csharp
  if (isElite && victimMaster?.inventory != null && newMaster.inventory != null)
  {
      vi.currentEquipmentIndex → ni.SetEquipmentIndex
      vi.alternateEquipmentIndex → ni.SetEquipmentIndexForSlot
  }
  ```

### Bug 9: vb.isElite sempre false no hook de morte
- **Sintoma**: Smart replace nunca substituía, elite marcado como normal
- **Causa**: O jogo remove o buff de elite ANTES do evento `OnCharacterDeath`
- **Solução**: Novo método `IsEliteEnemy(CharacterMaster)` que verifica `master.inventory.currentEquipmentIndex != EquipmentIndex.None`

### Bug 10: Métodos com assinatura errada
- `SpawnMinion` agora recebe `(GameObject prefab, CharacterMaster victimMaster, bool isElite)` — não mais `CharacterBody`
- `TrySmartReplace` agora recebe `(GameObject prefab, CharacterMaster victimMaster, bool isElite)`
- `IsEliteEnemy(CharacterMaster)` — novo helper

### Bug 11: HandleSpawnOrQueueOrReplace removido (código morto)
- Método com 40% de código nunca executado (verificação duplicada do OnEnemyDeath)
- Lógica de fila/replace movida direto pro OnEnemyDeath